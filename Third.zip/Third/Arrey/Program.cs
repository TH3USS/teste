﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrey
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaração de arrey
            int[] xpto;

            // Atribuição de tamanho
            xpto = new int[10];

            // Declaração com atribuição de tamanho
            int[] xpto1 = new int[10];

            // Declaração com atribuição de lista de inicialização
            int[] xpto2 = { 10, 20, 30, 40 };

            // Declaração de arrey com uso de variavel de valor constante
            const int arraytam = 10;
            int[] xpto3 = new int[arraytam];

            // Declaração de inicialização a paertir de lista da matriz
            int[] array1 = new int[] { 1, 3, 5, 7, 9 };

            // Propriedades de arrays
            int tam = xpto2.Length;
            Console.WriteLine(tam);


        }
    }
}
