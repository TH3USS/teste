﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Third
{
    class Program
    {
        static void Main(string[] args)
        {
            //int teste;
            //Console.WriteLine("escolha 1 - inclusao");
            //Console.WriteLine("escolha 2 - alteração");
            //Console.WriteLine("escolha 3 - exclusão");
            //Console.WriteLine("escolha uma opção");
            //teste = Int32.Parse(Console.ReadLine());
            ////teste = 1;

            //switch(teste)
            //{
            //    case 1:
            //        Console.WriteLine("Voce escolheu inclusão");
            //        break;
            //    case 2:
            //        Console.WriteLine("Voce escolheu alteração");
            //        break;
            //    case 3:
            //        Console.WriteLine("Voce escolheu exclusao");
            //        break;
            //    default:
            //        Console.WriteLine("Escolha default");
            //        break;
            //}


            ///// Laço de repetição While
            //int total = 0, gradeCounter = 0, gradeValue = 0;

            //while (gradeValue != -1)
            //{
            //    total = total + gradeValue;
            //    gradeCounter = gradeCounter + 1;

            //    Console.Write("Enter Integer Grade, -1 to quit: ");
            //    gradeValue = Int32.Parse(Console.ReadLine());
            //}
            //Console.WriteLine("A soma dos valores: " + total);


            ///// Laço For
            //for (int counter = 1; counter <= 5; counter++)
            //    Console.WriteLine("Mensagem");

            /////// Do-While
            //int cont = 1;
            //do
            //{
            //    Console.WriteLine(cont);
            //    cont++;
            //} while (cont <= 5);

            ///// Break
            string output = "";
            for (int count = 1; count <= 10; count++)
            {
                if (count == 5)
                    break;

                output += count + " ";
                Console.WriteLine("Valor: " + output);
            }
            Console.WriteLine("\n\n");
            //// Continue
            for (int count = 1; count <= 10; count++)
            {
                if (count == 5)
                    continue;

                output += count + " ";
                Console.WriteLine("Valor: " + output);
            }


            Console.ReadKey();
        }
    }
}
